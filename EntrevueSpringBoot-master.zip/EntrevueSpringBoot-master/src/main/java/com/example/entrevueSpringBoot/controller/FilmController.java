
  package com.example.entrevueSpringBoot.controller;
  
  import org.springframework.web.bind.annotation.RequestMapping; 
  import org.springframework.web.bind.annotation.RestController;
  
  import java.util.Optional;
  
  import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
  import org.springframework.web.bind.annotation.PathVariable;
  import org.springframework.web.bind.annotation.PostMapping; 
  import org.springframework.web.bind.annotation.RequestBody;
  
  import com.example.entrevueSpringBoot.model.Film; import
  com.example.entrevueSpringBoot.repository.FilmRepository;
  
  @RestController
  @RequestMapping("/films")
  public class FilmController {
  
  @Autowired 
  private FilmRepository filmRepository;
  
  public FilmController() {
	 	  
  }
  public FilmController(FilmRepository filmRepository) {
	  this.filmRepository = filmRepository; 
	  
  }
  
  @GetMapping("/films/{film_id}") 
  public Optional<Film> findFilmById(@PathVariable  Long id) {
	  return filmRepository.findById(id); 
  }
  
  @PostMapping("/films") 
  Film createnewFilm(@RequestBody Film newFilm) { 
	  return filmRepository.save(newFilm);

  }
}
  
 