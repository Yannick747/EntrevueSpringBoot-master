package com.example.entrevueSpringBoot.model;

import javax.persistence.*;
import java.util.*;


@Entity
@Table(name="films")
public class Film {
 @Id
 private Long film_id;
 private String titre;
 private String description;
	
 @ManyToMany
 @JoinTable(name="film_acteur",joinColumns=@JoinColumn(name="film_id"),inverseJoinColumns=@JoinColumn(name="acteur_id"))
 private List<Acteur> acteurs=new ArrayList<>();

 /*constructor*/
 public Film(Long film_id, String titre, String description) {
	
	this.film_id = film_id;
	this.titre = titre;
	this.description = description;
}

/*Add an actor to the list of actors*/
 public void addActeur(Acteur acteur) {
 
	 acteurs.add(acteur);
 }
 
 /*Getters and setters*/
public Long getFilm_id() {
	return film_id;
 }

 public void setFilm_id(Long film_id) {
	this.film_id = film_id;
 }

 public String getTitre() {
	return titre;
 }

 public void setTitre(String titre) {
	this.titre = titre;
 }

 public String getDescription() {
	return description;
 }

 public void setDescription(String description) {
	this.description = description;
 }

 public List<Acteur> getActeurs() {
	return acteurs;
 }

 public void setActeurs(List<Acteur> acteurs) {
	this.acteurs = acteurs;
 }

}
