
  package com.example.entrevueSpringBoot.controller;
  
  import org.springframework.web.bind.annotation.RequestMapping; 
  import org.springframework.web.bind.annotation.RestController;
  import java.util.Optional;
  import org.springframework.beans.factory.annotation.Autowired;
  import org.springframework.web.bind.annotation.GetMapping; 
  import org.springframework.web.bind.annotation.PathVariable; 
  import org.springframework.web.bind.annotation.PostMapping; 
  import org.springframework.web.bind.annotation.RequestBody;
  
  import com.example.entrevueSpringBoot.model.Acteur; 
  import com.example.entrevueSpringBoot.repository.ActeurRepository;
  
  @RestController
  @RequestMapping("/acteurs") 
  public class ActeurController {
  
  @Autowired 
  private ActeurRepository acteurRepository;
  
  public ActeurController() {
  }
  public ActeurController(ActeurRepository acteurRepository) {
  this.acteurRepository = acteurRepository;
  }
  
  @GetMapping("/acteurs/{acteur_id}") 
  Optional<Acteur> findActeurById(@PathVariable Long id) {
	return acteurRepository.findById(id);
  }
  
  @PostMapping("/acteurs") 
  Acteur createnewActeur(@RequestBody Acteur
  newActeur) { return acteurRepository.save(newActeur);
  } 
  
 }
 