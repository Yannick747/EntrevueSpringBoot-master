package com.example.entrevueSpringBoot.model;

import javax.persistence.*;
import java.util.*;

@Entity
@Table(name="acteurs")
public class Acteur {
  @Id
  private Long acteur_id;
  private String nom;
  private String prenom;
  
  
  @ManyToMany(mappedBy="acteurs")
  private List<Film> films=new ArrayList<>();

  /*Constructor*/
public Acteur(Long acteur_id, String nom, String prenom) {
	this.acteur_id = acteur_id;
	this.nom = nom;
	this.prenom = prenom;
}

 /*Getter and setter*/
public Long getActeur_id() {
	return acteur_id;
  }


  public void setActeur_id(Long acteur_id) {
	this.acteur_id = acteur_id;
  }


 public String getNom() {
	return nom;
 }


 public void setNom(String nom) {
	this.nom = nom;
 }


 public String getPrenom() {
	return prenom;
 }


 public void setPrenom(String prenom) {
	this.prenom = prenom;
 }


 public List<Film> getFilms() {
	return films;
 }


 public void setFilms(List<Film> films) {
	this.films = films;
 }
  
  
}
